var game = new Phaser.Game(1280, 720, Phaser.AUTO, 'phaser-example',
{ preload: preload, create: create});

function preload() {

    game.load.video('credits', 'creditsv1.mp4');
    game.load.spritesheet('01', 'tour.png', 40, 80);

    game.load.tilemap('jeu', 'jeu.json', null, Phaser.Tilemap.TILED_JSON);
    game.load.image('tiles', 'assetsvm.png')

}

var video;
var sprite;

function create() {
	video = game.add.video('credits');

    video.addToWorld(640, 360, 0.5, 0.5);

    video.play();

}

